/*
SQLyog - Free MySQL GUI v5.02
Host - 5.5.27 : Database - termdatabase
*********************************************************************
Server version : 5.5.27
*/


create database if not exists `termdatabase`;

USE `termdatabase`;

/*Table structure for table `termdb` */

DROP TABLE IF EXISTS `termdb`;

CREATE TABLE `termdb` (
  `No` varchar(20) DEFAULT NULL,
  `Name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `termdb` */

insert into `termdb` values 
('1000','First term'),
('1001','Second term'),
('1002','Another term'),
('1003','Miscellaneous term'),
('1004',''),
('1005','Term from app');
