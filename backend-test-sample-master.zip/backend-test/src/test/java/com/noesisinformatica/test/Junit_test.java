package com.noesisinformatica.test;

import junit.framework.TestCase;

public class Junit_test extends TestCase {
    TermService termService = null;

    @Override
    public void setUp() throws Exception {
        super.setUp();
        // instantiate data service
        termService = new TermService();
    }

    public void testApp(){

        // some terms must have been created during initialisation
        int termInTermService = termService.getAllTerm().size();
        System.out.println( "Number of terms : " + termInTermService);
        assert termInTermService > 0;
    }

    public void testSaveTerm() throws Exception {

        int termInTermService = termService.getAllTerm().size();
        // adding term should increment number
        termService.saveTerm("Term from app");
        assert termService.getAllTerm().size() > termInTermService;
    }

    public void testGetTerm() throws Exception {

        String testTerm = "Second test term";
        // adding term and getting last used id should give us the id
        termService.saveTerm(testTerm);
        long id = termService.getLastUsedId();
        // retrieving using id should give us the term
        assertEquals(testTerm, termService.getTermForId(id));
    }
}
