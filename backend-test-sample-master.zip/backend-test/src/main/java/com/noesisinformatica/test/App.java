package com.noesisinformatica.test;

/**
 * Hello world!
 *
 */
public class App {

    public static void main( String[] args ) throws ClassNotFoundException
    {
        //DataService dataService = new DataService();
        //System.out.println( "Number of terms : " + dataService.getAllTerm().size());
        //dataService.saveTerm("Term from app");
        TermService termService = new TermService();
        System.out.println( "Number of terms : " + termService.getAllTerm().size());
        termService.saveTerm("Term from app");
    	
    }
}
